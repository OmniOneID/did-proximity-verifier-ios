//
/*
 * Copyright 2026 OmniOne.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import SwiftUI
import UIKit

private struct LineHeightModifier: ViewModifier {
    let fontSize: CGFloat
    let multiple: CGFloat

    func body(content: Content) -> some View {
        let natural = UIFont.systemFont(ofSize: fontSize).lineHeight
        let extra = max(0, fontSize * multiple - natural)
        return content
            .lineSpacing(extra)
            .padding(.vertical, extra / 2)
    }
}

extension View {
    func lineHeight(_ multiple: CGFloat, fontSize: CGFloat) -> some View {
        modifier(LineHeightModifier(fontSize: fontSize, multiple: multiple))
    }
}
